package com.example.sts2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebstsPrj3ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.sts2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.sts2.entity.Product;
import com.example.sts2.service.ProductService;

@RestController
@RequestMapping("/stsapi")
public class productController {
	
	@Autowired
	ProductService ps;
	
	@PostMapping("/addProduct")
	public Product saveProduct(@RequestBody Product prd)
	{
		
		return ps.addProduct(prd);
		
	}
	
	@PostMapping("/addProducts")
	public List<Product> saveProductS(@RequestBody List<Product> prd)
	{
		
		return ps.addProducts(prd);
		
	}
	
	@GetMapping("/getproductbyid/{id}")
	public Product findProduct(@PathVariable int id)
	{
		
		return ps.getProductById(id);
		
	}
	
	@GetMapping("/getproductthrunames/{name}")
	public Product findProductthruname(@PathVariable String name)
	{
		
		return ps.getProductthruName(name);
		
	}
	
	
	@GetMapping("/getproducts")
	public List<Product> findallProducts()
	{
		
		return ps.getProducts();
		
	}
	
	@GetMapping("/deleteproduct/{id}")
	public String deleteProduct(@PathVariable int id)
	{
		
		return ps.deleteProduct(id);
		
	}
	
	@PutMapping("/updateProduct")
	public Product updProduct(@RequestBody Product prd)
	{
		
		return ps.updateProduct(prd);
		
	}

	/*
	 @PostMapping("/products")
	public ResponseEntity<Product> createProduct(@RequestBody Product prd) {
		try {
			Product _prd = pr.save(prd);
			return new ResponseEntity<>(_prd, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	*/

}

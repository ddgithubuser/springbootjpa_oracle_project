package com.example.sts2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.sts2.entity.Product;
import com.example.sts2.repository.ProductRepository;

@Service
public class ProductService {
	
    @Autowired
	private ProductRepository pr;
		
	
	public Product addProduct(Product prd)
	{		
		return pr.save(prd);
	}
	
	public List<Product> addProducts(List<Product> products)
	{		
		return pr.saveAll(products);
	}
	
	public Product getProductById(int id)
	{		
		return pr.findById(id).orElse(null);
	}
	
	
	 public Product getProductthruName(String name) {
        return pr.findByName(name);
    }
	
	
	public List<Product> getProducts()
	{		
		return pr.findAll();
	}
	
	
	public String deleteProduct(int id)
	{		
		 pr.deleteById(id);
		return "Product Deleted:"+id;
	}
	
	public Product updateProduct(Product p)
	{
		Product existingprd=pr.findById(p.getId()).orElse(null);
		existingprd.setName(p.getName());
		existingprd.setSizex(p.getSizex());
		existingprd.setQty(p.getQty());		
		return pr.save(existingprd);
	
	}


}



package com.example.sts2.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/*
 * @Entity
@Table(name="sts_product")
public class Product {
	
	@Id
	 @GeneratedValue(strategy = GenerationType.TABLE,generator = "user_table_generator")
    @TableGenerator(name = "user_table_generator",table = "tbl",initialValue = 1150 , pkColumnName = "PK_NAME", valueColumnName = "PK_VALUE")
	private int idx;
	private String name;
	private double sizex;
	private double qty;
	
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSize() {
		return sizex;
	}
	public void setSize(double size) {
		this.sizex = size;
	}
	public double getQty() {
		return qty;
	}
	public void setQty(double qty) {
		this.qty = qty;
	}
	

}*/
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
@Entity
@Table(name="sts_product")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE,generator = "user_table_generator")
    @TableGenerator(name = "user_table_generator",table = "tbln",initialValue = 1150 , pkColumnName = "PK_NAME", valueColumnName = "PK_VALUE")
	private int id;
	private String name;
	private double sizex;
	private double qty;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSizex() {
		return sizex;
	}
	public void setSizex(double sizex) {
		this.sizex = sizex;
	}
	public double getQty() {
		return qty;
	}
	public void setQty(double qty) {
		this.qty = qty;
	}

	
}
